<?php echo $PAGE->theme->settings->gheadingimporturl ?>
<?php echo $PAGE->theme->settings->gbodyimporturl ?>