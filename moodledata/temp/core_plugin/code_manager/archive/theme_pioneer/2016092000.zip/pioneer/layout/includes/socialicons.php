<div class="clearfix"> </div>
<div class="socialicons-container">
<div class="socialicons">
	<?php if ($PAGE->theme->settings->social1buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social1buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-facebook-square grow"></i></a>
        <?php } ?>
        <?php if ($PAGE->theme->settings->social2buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social2buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-twitter-square grow"></i></a>
        <?php } ?>
        <?php if ($PAGE->theme->settings->social3buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social3buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-pinterest-square grow"></i></a>
        <?php } ?>
	<?php if ($PAGE->theme->settings->social4buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social4buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-flickr grow"></i></a>
        <?php } ?>
	<?php if ($PAGE->theme->settings->social5buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social5buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-linkedin-square grow"></i></a>
        <?php } ?>
        <?php if ($PAGE->theme->settings->social6buttonurl) { ?>
	<a href="<?php echo $PAGE->theme->settings->social6buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-youtube-square grow"></i></a>
        <?php } ?>
	<?php if ($PAGE->theme->settings->social7buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social7buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-vimeo-square grow"></i></a>
        <?php } ?>
        <?php if ($PAGE->theme->settings->social8buttonurl) { ?>
        <a href="<?php echo $PAGE->theme->settings->social8buttonurl ?>" target="_blank" id="button"> <i class="fa fa-2x fa-google-plus-square grow"></i></a>
        <?php } ?>
</div> 
</div>
<div class="clearfix"> </div>