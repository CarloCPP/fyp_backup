$(document).ready(function(){
  $('.topcarousel').slick({
    autoplay: true,
    autoplaySpeed: 5000,
  dots: false,
  arrows: true,
  infinite: true,
  fade: true,
  slidesToShow: 1,
  slidesToScroll: 1
});
});
